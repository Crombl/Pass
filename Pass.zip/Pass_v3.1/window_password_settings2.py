import customtkinter as ctk
import operation_with_conf as conf
import darkdetect
import threading

def password_window(textfieldIS, okIS, cancelIS, Theme_element):

    ramka_color = {'Textfield_border': '', 'text': '', 'Button_border_color': '', 'hover': ''}
    if Theme_element == "dark":
        ramka_color['Textfield_border'] = "gray"
        ramka_color['text'] = "white"
        ramka_color["Button_border_color"] = "darkgray"
        ramka_color["hover"] = "gray"
    elif Theme_element == "system":
        if darkdetect.isDark():
            ramka_color['Textfield_border'] = "gray"
            ramka_color['text'] = "white"
            ramka_color["Button_border_color"] = "darkgray"
            ramka_color["hover"] = "gray"
        else:
            ramka_color['Textfield_border'] = "lightgray"
            ramka_color['text'] = "black"
            ramka_color["Button_border_color"] = "lightgray"
            ramka_color["hover"] = "white"
    elif Theme_element == "light":
        ramka_color['Textfield_border'] = "lightgray"
        ramka_color['text'] = "black"
        ramka_color["Button_border_color"] = "lightgray"
        ramka_color["hover"] = "white"

    root = ctk.CTk()
    root.geometry("400x250")
    root.wm_iconbitmap('image/Pass-logo.ico')
    root.title("Pass")

    textfield = ctk.CTkEntry(root, placeholder_text=textfieldIS, width=250, height=35, border_width=1.7, border_color=ramka_color['Textfield_border'])
    textfield.pack(side="top", pady=(60, 30))
    
    def close_window():
        root.focus_set()
        def close():
            root.destroy()
        root.after(100, close)
    root.bind("<Escape>", lambda event: close_window())

    def process_enter():
        def enter():
            try:
                entered_text = textfield.get()
                if entered_text != "":
                    conf.write_config('Settings', 'password', entered_text)
                    root.destroy()
                else:
                    textfield.configure(border_width=1.5, border_color="red")
                    def take_off_red_field():
                        textfield.configure(border_width=1.5, border_color=ramka_color['Textfield_border'])
                    textfield.bind("<Key>", lambda event: take_off_red_field())
            except Exception as e:
                print(f"помилка в Window_password_setings: {e}")
        root.after(100, enter)
    textfield.bind("<Return>", lambda event: process_enter())

    button_frame = ctk.CTkFrame(root, fg_color="transparent")
    button_frame.pack(side="top")

    cancel_button = ctk.CTkButton(button_frame, text=cancelIS, width=80, height=30, fg_color="transparent", 
    text_color= ramka_color['text'], hover_color="#c70c1f", command=close_window, border_width=0.8, border_color=ramka_color["Button_border_color"])
    cancel_button.pack(side="left")

    ok_button = ctk.CTkButton(master=button_frame, text=okIS, text_color= ramka_color['text'], 
    width=60, height=30, fg_color="transparent", hover_color=ramka_color["hover"], 
    command=process_enter, border_width=0.8, border_color=ramka_color["Button_border_color"])
    ok_button.pack(side="left", padx=(90,0))

    root._set_appearance_mode(Theme_element)
    textfield._set_appearance_mode(Theme_element)
    button_frame._set_appearance_mode(Theme_element)
    cancel_button._set_appearance_mode(Theme_element)
    ok_button._set_appearance_mode(Theme_element)    
    root.maxsize(400, 250)
    root.minsize(400, 250)
    root.mainloop()