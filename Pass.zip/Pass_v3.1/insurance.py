import configparser

config = configparser.ConfigParser()

def write_config():

    config['Settings'] = {
        'autoload': f'off',
        'maincolor': f'blue',
        'colormode': f'system',
        'language': f'Ukrainian',
        'password': f'none',
        'seatching_by': f'name'
    }

    config['Ukrainian'] = {
        'archive': 'Архів',
        'edit': 'Редагувати',
        'settings': 'Налаштування',
        'search': 'Шукати',
        'name': 'Назва',
        'next': 'Далі', #5
        'autoload': 'Автозавантаження (недоступно)',
        'maincolor': 'Головний колір',
        'theme': 'Тема',
        'language': 'Мова',
        'password': 'Пароль', #10
        'search_by': 'Шукати за',
        'save_all_passwords_in_simgle_file': 'Зберегти всі паролі в один файл',
        'press_Enter_to_continue': 'Натисність Enter, щоб продовжити',
        'enter_the_password': 'Введіть пароль',
        'post': 'Пошта', #15
        'save': 'Зберегти',
        'create': 'Створити',
        'cancel': 'Скасувати',
        'continue': 'Продовжити',
        'do_it': 'Зробити', #20
        'password_saved': 'Пароль збережено',
        'field_is_empty': "Поле для вводу порожнє",
        'the_password_is_incorrect': "Пароль не вірний",
        'change': 'змінити',
        'delete': 'видалити', #25
        'ok': 'ок',
        'green': 'Зелений',
        'blue': 'Синій',
        'dark': 'Темна',
        'system': 'Системна', #30
        'light': 'Світла',
        'no_matches_found': 'Збігів не знайдено.',
        'all_pass': 'Напишіть в пошук all, якщо хочете побачити всі паролі',
        'it_seems_like_it_is_not_an_email': 'Схоче, що це не пошта'
    }

    config['english'] = {
        'archive': 'Archive',
        'edit': 'Edit',
        'settings': 'Settings',
        'search': 'Search',
        'name': 'Name',
        'next': 'Next', #5
        'autoload': 'Autoload (unavalable)',
        'maincolor': 'Main color',
        'theme': 'Theme',
        'language': 'Language',
        'password': 'Password', #10
        'search_by': 'Search by',
        'save_all_passwords_in_simgle_file': 'Save all passwords in simgle file',
        'press_Enter_to_continue': 'Press Enter to continue',
        'enter_the_password': 'Enter the password',
        'post': 'Email', #15
        'save': 'Save',
        'create': 'create',
        'cancel': 'cancel',
        'continue': 'Continue',
        'do_it': 'do it', #20
        'password_saved': 'Пароль збережено',
        'field_is_empty': "the field is empty",
        'the_password_is_incorrect': "the password is incorrect",
        'change': 'change',
        'delete': 'delete', #25
        'ok': 'ok',
        'green': 'Green',
        'blue': 'Blue',
        'dark': 'Dark',
        'system': 'System', #30
        'light': 'Light',
        'no_matches_found': 'No matches found.',
        'all_pass': 'Write "all", if you want to see all passwords',
        'it_seems_like_it_is_not_an_email': 'It seems like there is not an email',
    }

    # Зберігаємо конфігурацію в файл
    with open('config.conf', 'w') as configfile:
        config.write(configfile)