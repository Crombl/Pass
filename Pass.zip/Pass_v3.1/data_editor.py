import sqlite3
import os

def save_user_data(name, email, password):
    try:
        conn = sqlite3.connect('database.db')
        conn.execute("PRAGMA key='7865342598'")

        # Створюємо курсор для взаємодії з базою даних
        cursor = conn.cursor()

        # Створюємо таблицю для зберігання даних
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                name TEXT,
                email TEXT,
                password TEXT
            )
        ''')

        # Зберігаємо дані
        cursor.execute('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', (name, email, password))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"помилка: {e}")

def search_users(query, ima, poshta, parol, search_criterion='email'):
    conn = sqlite3.connect('database.db')
    conn.execute("PRAGMA key='7865342598'")
    cursor = conn.cursor()
    if os.path.getsize('database.db') == 0:
        return ""


    if search_criterion == 'email':
        cursor.execute('SELECT * FROM users WHERE email LIKE ?', ('%' + query + '%',))
    elif search_criterion == 'name':
        cursor.execute('SELECT * FROM users WHERE name LIKE ?', ('%' + query + '%',))
    # Додайте інші умови за потреби

    results = cursor.fetchall()
    conn.close()

    users = [f"\n{ima}: {row[1]}\n{poshta}: {row[2]}\n{parol}: {row[3]}\n" for row in results]

    return list(users)
