import customtkinter
from PIL import Image, ImageTk
import operation_with_conf as conf
import os
import window_password_settings2 as cp
import data_editor as saver
import threading
import time
import darkdetect
from tkinter import filedialog
import tkinter as tk
import sys

interface = conf.read_config('Settings')
language_pack = conf.read_config(interface[3])

palette = {'BorderColor': '', 'TextColor': '', 'FrameColor': '', 'hover': ''}
if interface[2] == "dark":
    palette['BorderColor'] = "gray"
    palette['TextColor'] = "white"
    palette["FrameColor"] = "#2e2e2e"
    palette["hover"] = "gray"
    archive_picture = customtkinter.CTkImage(Image.open("image/archive.png"))
    edit_picture = customtkinter.CTkImage(Image.open("image/edit.png"))
    settings_picture = customtkinter.CTkImage(Image.open("image/settings.png"))
elif interface[2] == "system":
    if darkdetect.isDark():
        palette['BorderColor'] = "gray"
        palette['TextColor'] = "white"
        palette["FrameColor"] = "#2e2e2e"
        palette["hover"] = "gray"
        archive_picture = customtkinter.CTkImage(Image.open("image/archive.png"))
        edit_picture = customtkinter.CTkImage(Image.open("image/edit.png"))
        settings_picture = customtkinter.CTkImage(Image.open("image/settings.png"))
    else:
        palette['BorderColor'] = "lightgray"
        palette['TextColor'] = "black"
        palette["FrameColor"] = "#e3e3e3"
        palette["hover"] = "white"
        archive_picture = customtkinter.CTkImage(Image.open("image/archive_dark.png"))
        edit_picture = customtkinter.CTkImage(Image.open("image/edit_dark.png"))
        settings_picture = customtkinter.CTkImage(Image.open("image/settings_dark.png"))
elif interface[2] == "light":
    palette['BorderColor'] = "lightgray"
    palette['TextColor'] = "black"
    palette["FrameColor"] = "#e3e3e3"
    palette["hover"] = "white"
    archive_picture = customtkinter.CTkImage(Image.open("image/archive_dark.png"))
    edit_picture = customtkinter.CTkImage(Image.open("image/edit_dark.png"))
    settings_picture = customtkinter.CTkImage(Image.open("image/settings_dark.png"))





root = customtkinter.CTk()
root.wm_iconbitmap('image/Pass-logo.ico')
root.geometry("900x550")
root.title("Pass")
customtkinter.set_default_color_theme(interface[1])

def close_window():
    root.focus_set()
    def close():
        root.destroy()
    root.after(100, close)
root.bind("<Escape>", lambda event: close_window())


frame_archive = customtkinter.CTkFrame(root, fg_color="transparent")
if interface[4] == "none":
    frame_archive.pack(side="right", fill ="both", expand=True)

search_element_frame = customtkinter.CTkFrame(frame_archive, fg_color="transparent")
search_element_frame.pack(side="top", fill ="x", anchor="nw")

textfield_archive = customtkinter.CTkEntry(search_element_frame, placeholder_text=language_pack[3], border_color=palette['BorderColor'])
textfield_archive.configure(width=400, height=35)
textfield_archive.pack(padx=(120, 10), pady=(20, 0), side="left", anchor="nw")

answer_frame_archive = customtkinter.CTkFrame(frame_archive, fg_color="transparent")
answer_frame_archive.pack(side="bottom", fill="both", expand=True, padx=(120, 0), pady=(5, 15))

def button_search_archive_function():
    if textfield_archive.get() == "":
        text_length = language_pack[33]
    elif textfield_archive.get() == "all":
        answer = saver.search_users("", language_pack[4], language_pack[15], language_pack[10],search_criterion=interface[5])
        text_length = '\n'.join(answer)
    else:
        answer = saver.search_users(textfield_archive.get(), language_pack[4], language_pack[15], language_pack[10], search_criterion=interface[5])
        text_length = '\n'.join(answer)

    if text_length == "":
        text_length = language_pack[32]

    if not hasattr(button_search_archive_function, 'tk_textbox'):
        # Створюємо текстбокс і скролбар при його відсутності
        if len(text_length.split('\n')) > 30:
            button_search_archive_function.tk_textbox = customtkinter.CTkTextbox(answer_frame_archive, state="normal", fg_color="transparent", text_color=palette["TextColor"])
            button_search_archive_function.tk_textbox._set_appearance_mode(interface[2])
        else:
            button_search_archive_function.tk_textbox = customtkinter.CTkTextbox(answer_frame_archive, state="normal", fg_color="transparent", text_color=palette["TextColor"])
            button_search_archive_function.tk_textbox._set_appearance_mode(interface[2])

        button_search_archive_function.tk_textbox.pack(side="bottom", anchor="n", expand=True, fill="both")
        button_search_archive_function.ctk_textbox_scrollbar = customtkinter.CTkScrollbar(answer_frame_archive, command=button_search_archive_function.tk_textbox.yview)
    
    # Оновлюємо вміст текстбоксу
    button_search_archive_function.tk_textbox.configure(state="normal")  # Дозволяємо редагування тексту
    button_search_archive_function.tk_textbox.delete("1.0", "end")  # Очищаємо попередні дані
    button_search_archive_function.tk_textbox.insert("1.0", text_length)  # Вставляємо нові дані
    button_search_archive_function.tk_textbox.configure(state="disabled")  # Забороняємо редагування тексту


textfield_archive.bind("<Return>", lambda event: button_search_archive_function())
send_picture = customtkinter.CTkImage(Image.open("image/send.png"))
button_search_archive = customtkinter.CTkButton(search_element_frame, image=send_picture, text="", command=button_search_archive_function)
button_search_archive.configure(width=35, height=35)
button_search_archive.pack(padx=(0, 120), pady=(20, 0), side="left", anchor="nw")




edit_frame = customtkinter.CTkFrame(root, fg_color=palette["FrameColor"])
info_edit = {}
now = ""
def next_slide():
    global now
    global info_edit
    if textfield_edit.get() != "" and 'name' not in info_edit:
        info_edit['name'] = textfield_edit.get()
        edit_button.focus_set()
        textfield_edit.delete(0, customtkinter.END)
        textfield_edit.configure(placeholder_text=language_pack[15])
        now="post"
    elif 'name' in info_edit and textfield_edit.get() != "" and 'post' not in info_edit and '@' in textfield_edit.get():
        info_edit['post'] = textfield_edit.get()
        edit_button.focus_set()
        textfield_edit.delete(0, customtkinter.END)
        textfield_edit.configure(placeholder_text=language_pack[10])
        edit_button.configure(text=language_pack[16])
        now="password"
    elif 'post' in info_edit and textfield_edit.get() != "":
        info_edit['password'] = textfield_edit.get()
        edit_button.focus_set()
        textfield_edit.delete(0, customtkinter.END)
        textfield_edit.configure(placeholder_text=language_pack[4])
        edit_button.configure(text=language_pack[5])
        now = "name"
        saver.save_user_data(info_edit['name'], info_edit['post'], info_edit['password'])
        info_edit.clear()

        succesfull_sign_image = customtkinter.CTkImage(Image.open("image/saved.png"))
        edit_succesfull_sign = customtkinter.CTkButton(master=edit_frame, image=succesfull_sign_image, fg_color="green", text=None, width=30, height=30, state="disabled")
        edit_succesfull_sign._set_appearance_mode(interface[2])
        edit_succesfull_sign.pack(side="bottom", anchor="se", pady=10, padx=10)
        def close_sevaed_sign():
            time.sleep(1)
            edit_succesfull_sign.pack_forget()
        timer_thread = threading.Thread(target=close_sevaed_sign)
        timer_thread.start()
    else:
        if '@' not in textfield_edit.get() and now == "post":
            no_dog_msg = customtkinter.CTkButton(edit_frame, text=language_pack[34], 
            fg_color=palette["hover"], hover_color=palette["hover"], text_color=palette["TextColor"])
            no_dog_msg._set_appearance_mode(interface[2])
            no_dog_msg.pack(side="bottom", anchor="se", padx=10, pady=10)
            def close_sevaed_sign():
                time.sleep(3)
                no_dog_msg.pack_forget()
            timer_thread = threading.Thread(target=close_sevaed_sign)
            timer_thread.start()
        # e_entry.configure(fg_color="#c4001c", placeholder_text_color="black")
        textfield_edit.configure(border_width=2, border_color="red")
        edit_button.focus_set()
        def take_off_red_field(event):
            textfield_edit.configure(border_width=2, border_color="gray")
        textfield_edit.bind("<Button-1>", take_off_red_field)
textfield_edit = customtkinter.CTkEntry(master=edit_frame,  placeholder_text=language_pack[4], width=200, height=35, border_color=palette['BorderColor'])
textfield_edit.pack(side="top", pady=(160, 0))
edit_button = customtkinter.CTkButton(master=edit_frame, text=language_pack[5], command=next_slide, width=200, height=35)
edit_button.pack(side="top", padx=120, pady=(20, 0), anchor="s")
textfield_edit.bind("<Return>", lambda event: next_slide())



frame_settings = customtkinter.CTkFrame(master=root, fg_color="transparent")
frame_autoload_settings = customtkinter.CTkFrame(master=frame_settings, fg_color="transparent")
frame_autoload_settings.pack(pady=(30, 0), padx=30, side="top", fill="x")
lable_autoload_settings = customtkinter.CTkLabel(master=frame_autoload_settings, text=language_pack[6])
lable_autoload_settings.pack(side="left", padx=(10, 0))
def checkbox_event():
    switch = ""
    if checkbox_autoload_settins.get() == "on":
        switch = "on"
        conf.write_config('Settings', 'autoload', 'on')
    elif checkbox_autoload_settins.get() == "off":
        switch = "off"
        conf.write_config('Settings', 'autoload', 'off')
    conf.write_config('Settings', 'autoload', switch)
check_var = customtkinter.StringVar(value=interface[0])
checkbox_autoload_settins = customtkinter.CTkCheckBox(master=frame_autoload_settings, text="", variable=check_var, onvalue="on", offvalue="off", checkbox_width=21, checkbox_height=21, command=checkbox_event)
checkbox_autoload_settins.pack(side="left", padx=(10, 0))



frame_maincolor_settins = customtkinter.CTkFrame(master=frame_settings, fg_color="transparent")
frame_maincolor_settins.pack(pady=(13, 0), padx=30, side="top", fill="x")
lable_maincolor_settings = customtkinter.CTkLabel(master=frame_maincolor_settins, text=language_pack[7])
lable_maincolor_settings.pack(side="left", padx=(10, 0))
def segmented_button_callback():
    value = maincolor_mode.get()
    if value == 1:
        conf.write_config('Settings', 'maincolor', 'green')
        os.execl(sys.executable, sys.executable, '"' + '" "'.join(sys.argv) + '"')
    elif value == 2:
        conf.write_config('Settings', 'maincolor', 'blue')
        os.execl(sys.executable, sys.executable, '"' + '" "'.join(sys.argv) + '"')
maincolor_mode = tk.IntVar(value=0)
radiobuttonGreen_maincolor_settins = customtkinter.CTkRadioButton(frame_maincolor_settins, text=language_pack[27], command=segmented_button_callback, variable= maincolor_mode, value=1, radiobutton_width=18, radiobutton_height=18)
radiobuttonBlue_maincolor_settins = customtkinter.CTkRadioButton(frame_maincolor_settins, text=language_pack[28], command=segmented_button_callback, variable= maincolor_mode, value=2, radiobutton_width=18, radiobutton_height=18)
radiobuttonGreen_maincolor_settins.pack(side="left", padx=(30, 0), pady=0)
radiobuttonBlue_maincolor_settins.pack(side="left", padx=0, pady=0)
radiobuttonGreen_maincolor_settins._set_appearance_mode(interface[2])
radiobuttonBlue_maincolor_settins._set_appearance_mode(interface[2])

if interface[1] == 'green':
    maincolor_mode.set(1)
elif interface[1] == 'blue':
    maincolor_mode.set(2)



frame_theme_settings = customtkinter.CTkFrame(master=frame_settings, fg_color="transparent")
frame_theme_settings.pack(pady=(15, 0), padx=30, side="top", fill="x")
lable_theme_settings = customtkinter.CTkLabel(master=frame_theme_settings, text=language_pack[8])
lable_theme_settings.pack(side="left", padx=(10, 0))
def radiobutton_event():
    value = mode.get()
    if value == 1:
        conf.write_config('Settings', 'colormode', 'dark')
        os.execl(sys.executable, sys.executable, '"' + '" "'.join(sys.argv) + '"')
    elif value == 2:
        conf.write_config('Settings', 'colormode', 'system')
        os.execl(sys.executable, sys.executable, '"' + '" "'.join(sys.argv) + '"')
    elif value == 3:
        conf.write_config('Settings', 'colormode', 'light')
        os.execl(sys.executable, sys.executable, '"' + '" "'.join(sys.argv) + '"')
mode = tk.IntVar(value=0)
radiobuttonDark_theme_settings = customtkinter.CTkRadioButton(frame_theme_settings, text=language_pack[29], command=radiobutton_event, variable= mode, value=1, radiobutton_width=18, radiobutton_height=18)
radiobuttonSystem_theme_settings = customtkinter.CTkRadioButton(frame_theme_settings, text=language_pack[30], command=radiobutton_event, variable= mode, value=2, radiobutton_width=18, radiobutton_height=18)
radiobuttonLight_theme_settings = customtkinter.CTkRadioButton(frame_theme_settings, text=language_pack[31], command=radiobutton_event, variable= mode, value=3, radiobutton_width=18, radiobutton_height=18)
radiobuttonDark_theme_settings.pack(side="left", padx=(30, 0), pady=0)
radiobuttonSystem_theme_settings.pack(side="left", padx=0, pady=0)
radiobuttonLight_theme_settings.pack(side="left", padx=0, pady=0)
radiobuttonDark_theme_settings._set_appearance_mode(interface[2])
radiobuttonSystem_theme_settings._set_appearance_mode(interface[2])
radiobuttonLight_theme_settings._set_appearance_mode(interface[2])

if interface[2] == 'dark':
    mode.set(1)
elif interface[2] == 'system':
    mode.set(2)
elif interface[2] == 'light':
    mode.set(3)



frame_language_settings = customtkinter.CTkFrame(master=frame_settings, fg_color="transparent")
frame_language_settings.pack(pady=(15, 0), padx=30, side="top", fill="x")
lable_language_settings = customtkinter.CTkLabel(master=frame_language_settings, text=language_pack[9])
lable_language_settings.pack(side="left", padx=(10, 0))
def combobox_callback(choice):
    lan= ""
    if choice == "Українська":
        lan = "Ukrainian"
    elif choice == "English":
        lan = "english"
    conf.write_config('Settings', 'language', lan)
    os.execl(sys.executable, sys.executable, '"' + '" "'.join(sys.argv) + '"')
combobox_language_settings = customtkinter.CTkComboBox(frame_language_settings, values=["English", "Українська"], width=130, height=23, corner_radius=20, command=combobox_callback)
lan = ""
if interface[3] == "Ukrainian":
    lan = "Українська"
elif interface[3] == "english":
    lan= "English"
combobox_language_settings.set(lan)
combobox_language_settings.pack(side="left", padx=(10, 0))



#запит паролю при вході в програму
if interface[4] != "none":
    frame_security_settings = customtkinter.CTkFrame(master=root, fg_color="transparent")
    frame_security_settings._set_appearance_mode(interface[2])
    frame_security_settings.pack(fill="both", expand=True)
    textfield_security_settings = customtkinter.CTkEntry(master=frame_security_settings, placeholder_text=language_pack[14], width=180, height=37, border_color=palette['BorderColor'])
    textfield_security_settings._set_appearance_mode(interface[2])
    textfield_security_settings.pack(anchor="center", side="top", pady=(220, 0))
    def process_enter(event):
        if event.keysym == "Return":
            entered_text = textfield_security_settings.get()

            def take_off_red_field(event):
                    textfield_security_settings.configure(border_width=2, border_color=palette['BorderColor'])

            if entered_text != "":
                if entered_text == interface[4]:
                    frame_security_settings.pack_forget()
                    frame_mainmenu.pack(side="left", fill="y")
                    frame_archive.pack(side="right", fill ="both", expand=True)
                    root.bind("<Alt-KeyPress-1>", lambda event: search())
                    root.bind("<Alt-KeyPress-2>", lambda event: edit())
                    root.bind("<Alt-KeyPress-3>", lambda event: propertis())
                else:
                    textfield_security_settings.configure(border_width=2, border_color="red")
                    textfield_security_settings.bind("<Key>", take_off_red_field)
                    hint_security_settings.configure(text=language_pack[23])
            else:
                textfield_security_settings.configure(border_width=2, border_color="red")
                textfield_security_settings.bind("<Key>", take_off_red_field)
                hint_security_settings.configure(text=language_pack[22])   
    textfield_security_settings.bind("<Return>", process_enter)
    hint_security_settings = customtkinter.CTkLabel(master=frame_security_settings, text=language_pack[13], text_color="grey")
    hint_security_settings._set_appearance_mode(interface[2])
    hint_security_settings.pack(anchor="center", side="bottom", pady=(0, 25))



#налаштування паролю
frame_password_settings = customtkinter.CTkFrame(master=frame_settings, fg_color="transparent")
frame_password_settings.pack(pady=(15, 0), padx=30, side="top", fill="x")
lable_password_settings = customtkinter.CTkLabel(master=frame_password_settings, text=language_pack[10])
lable_password_settings.pack(side="left", padx=(10, 0))

def create_password():
    cp.password_window(language_pack[14], language_pack[26], language_pack[18], interface[2])
buttonCreate_password_settings = customtkinter.CTkButton(master=frame_password_settings, width=100, height=23, command=create_password)
buttonCreate_password_settings.pack(side="left", padx=(10, 0))
if interface[4] == "none":
    buttonCreate_password_settings.configure(text=language_pack[17])
else:
    buttonCreate_password_settings.configure(text=language_pack[24])
    def del_password():
        conf.write_config('Settings', 'password', 'none')
        buttonDelete_password_settings.pack_forget()
    buttonDelete_password_settings = customtkinter.CTkButton(master=frame_password_settings, width=100, height=23, command=del_password, 
    hover_color="#a31523", fg_color="transparent", border_width=0.7, border_color="lightgray", text=language_pack[25], text_color=palette["TextColor"])
    buttonDelete_password_settings._set_appearance_mode(interface[2])
    buttonDelete_password_settings.pack(side="left", padx=(10, 0))



frame_searchmode_settings = customtkinter.CTkFrame(master=frame_settings, fg_color="transparent")
frame_searchmode_settings.pack(pady=(15, 0), padx=30, side="top", fill="x")
lable_searchmode_settings = customtkinter.CTkLabel(master=frame_searchmode_settings, text=language_pack[11])
lable_searchmode_settings.pack(side="left", padx=(10, 0))

def combobox_callback(choice):
    seab = ""
    if choice == language_pack[4]:
        seab = "name"
    elif choice == language_pack[15]:
        seab = "email"
    conf.write_config('Settings', 'seatching_by', seab)
    os.execl(sys.executable, sys.executable, '"' + '" "'.join(sys.argv) + '"') #перезавантажує вікно
combobox_searchmode_settings = customtkinter.CTkComboBox(frame_searchmode_settings, values=[language_pack[15], language_pack[4]], width=130, height=23, corner_radius=20, command=combobox_callback)
sb = ""
if interface[5] == "name":
    sb = language_pack[4]
elif interface[5] == "email":
    sb = language_pack[15]
combobox_searchmode_settings.set(sb)
combobox_searchmode_settings.pack(side="left", padx=(10, 0))



frame_save_setings = customtkinter.CTkFrame(master=frame_settings, fg_color="transparent")
frame_save_setings.pack(pady=(15, 0), padx=30, side="top", fill="x")
lable_save_setings = customtkinter.CTkLabel(master=frame_save_setings, text=language_pack[12])
lable_save_setings.pack(side="left", padx=(10, 0))

def save_in_single_file():
    answer = saver.search_users("", language_pack[4], language_pack[15], language_pack[10],search_criterion=interface[5])
    text_sense = '\n'.join(answer)

    save_root = tk.Tk()
    save_root.withdraw()
    file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
    
    with open(file_path, 'w') as file:
        file.write(text_sense)
    save_root.destroy()
button_save_setings = customtkinter.CTkButton(master=frame_save_setings, text=language_pack[20], width=100, height=23, command=save_in_single_file)
button_save_setings.pack(side="left", padx=(10, 0))



def search():
    edit_frame.pack_forget()
    frame_settings.pack_forget()
    frame_archive.pack(side="right", fill ="both", expand=True)

def edit():
    frame_archive.pack_forget()
    frame_settings.pack_forget()
    edit_frame.pack(side="right", fill ="both", expand=True, pady=35, padx=50)

def propertis():
    edit_frame.pack_forget()
    frame_archive.pack_forget()
    frame_settings.pack(side="right", fill ="both", expand=True)

if interface[4] == "none":
    root.bind("<Alt-KeyPress-1>", lambda event: search())
    root.bind("<Alt-KeyPress-2>", lambda event: edit())
    root.bind("<Alt-KeyPress-3>", lambda event: propertis())

frame_mainmenu = customtkinter.CTkFrame(master=root, fg_color=palette["FrameColor"])
if interface[4] == "none":
    frame_mainmenu.pack(side="left", fill="y")

# archive_picture = customtkinter.CTkImage(Image.open("image/archive.png"))
buttonSearch_mainmenu = customtkinter.CTkButton(frame_mainmenu, text=language_pack[0], fg_color="transparent", hover_color=palette['hover'], anchor="w", image=archive_picture, font=("Arial", -12, "bold"), command=search)
buttonSearch_mainmenu.configure(width=140, height=35, text_color=palette["TextColor"])
buttonSearch_mainmenu.pack(padx=16, pady=(20, 3))

# edit_picture = customtkinter.CTkImage(Image.open("image/edit.png"))
buttonEdit_mainmenu = customtkinter.CTkButton(master=frame_mainmenu, text=language_pack[1], fg_color="transparent", hover_color=palette['hover'], anchor="w", image=edit_picture, font=("Arial", -12, "bold"), command=edit)
buttonEdit_mainmenu.configure(width=140, height=35, text_color=palette["TextColor"])
buttonEdit_mainmenu.pack(padx=16, pady=3)

# settings_picture = customtkinter.CTkImage(Image.open("image/settings.png"))
buttonSettings_mainmenu = customtkinter.CTkButton(master=frame_mainmenu, text=language_pack[2], fg_color="transparent", hover_color=palette['hover'], image=settings_picture, anchor="w", font=("Arial", -12, "bold"), command=propertis)
buttonSettings_mainmenu.configure(width=140, height=35, text_color=palette["TextColor"])
buttonSettings_mainmenu.pack(side="bottom", padx=16, pady=20)



root._set_appearance_mode(interface[2])
frame_archive._set_appearance_mode(interface[2])
search_element_frame._set_appearance_mode(interface[2])
textfield_archive._set_appearance_mode(interface[2])
answer_frame_archive._set_appearance_mode(interface[2])
button_search_archive._set_appearance_mode(interface[2])
edit_frame._set_appearance_mode(interface[2])
textfield_edit._set_appearance_mode(interface[2])
edit_button._set_appearance_mode(interface[2])
frame_settings._set_appearance_mode(interface[2])
frame_autoload_settings._set_appearance_mode(interface[2])
lable_autoload_settings._set_appearance_mode(interface[2])
checkbox_autoload_settins._set_appearance_mode(interface[2])
frame_maincolor_settins._set_appearance_mode(interface[2])
lable_maincolor_settings._set_appearance_mode(interface[2])
frame_theme_settings._set_appearance_mode(interface[2])
lable_theme_settings._set_appearance_mode(interface[2])
frame_language_settings._set_appearance_mode(interface[2])
lable_language_settings._set_appearance_mode(interface[2])
combobox_language_settings._set_appearance_mode(interface[2])
frame_password_settings._set_appearance_mode(interface[2])
lable_password_settings._set_appearance_mode(interface[2])
buttonCreate_password_settings._set_appearance_mode(interface[2])
frame_searchmode_settings._set_appearance_mode(interface[2])
lable_searchmode_settings._set_appearance_mode(interface[2])
combobox_searchmode_settings._set_appearance_mode(interface[2])
frame_save_setings._set_appearance_mode(interface[2])
lable_save_setings._set_appearance_mode(interface[2])
button_save_setings._set_appearance_mode(interface[2])
frame_mainmenu._set_appearance_mode(interface[2])
buttonSearch_mainmenu._set_appearance_mode(interface[2])
buttonEdit_mainmenu._set_appearance_mode(interface[2])
buttonSettings_mainmenu._set_appearance_mode(interface[2])




root.maxsize(1000, 600)
root.minsize(680, 400)
if interface[0] == "on":
    def start():
        root.iconify()
    root.after(0, start)
root.mainloop()