import configparser
import insurance

config = configparser.ConfigParser()
interface = []

def write_config(section, option, new_value):
    # Читаємо існуючий конфігураційний файл
    config = configparser.ConfigParser()
    config.read('config.conf')

    # Змінюємо значення параметра
    if not config.has_section(section):
        config.add_section(section)
    config.set(section, option, new_value)

    # Зберігаємо змінений конфігураційний файл
    with open('config.conf', 'w') as configfile:
        config.write(configfile)

# section = 'Settings'
# option = 'colormode'
# new_value = 'light'

# write_config(section, option, new_value)

def read_config(set):
    config = configparser.ConfigParser()
    config.read('config.conf')

    if not set in config:
        insurance.write_config()

    config.read('config.conf')
    parameters_list = []

    if set in config:
        for option in config.options(set):
            value = config.get(set, option)
            parameters_list.append(value)

    return parameters_list
